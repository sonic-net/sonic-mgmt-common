#!/usr/bin/python
# Copyright (c) 2015 Dell Inc.
#
# Licensed under the Apache License, Version 2.0 (the "License"); you may
# not use this file except in compliance with the License. You may obtain
# a copy of the License at http://www.apache.org/licenses/LICENSE-2.0
#
# THIS CODE IS PROVIDED ON AN  *AS IS* BASIS, WITHOUT WARRANTIES OR
# CONDITIONS OF ANY KIND, EITHER EXPRESS OR IMPLIED, INCLUDING WITHOUT
# LIMITATION ANY IMPLIED WARRANTIES OR CONDITIONS OF TITLE, FITNESS
# FOR A PARTICULAR PURPOSE, MERCHANTABLITY OR NON-INFRINGEMENT.
#
# See the Apache Version 2.0 License for specific language governing
# permissions and limitations under the License.

import cps
import cps_utils
import cps_object
import sys
import bytearray_utils

nas_os_if_keys = [
    'base-port/interface',
    'base-port/physical',
    'base-port/front-panel-ports']

default_chassis_id = 1
default_slot_id = 1


def get_if_keys():
    return nas_os_if_keys

cps_utils.add_attr_type('base-port/front-panel-port/default-name', 'string')
cps_utils.add_attr_type('base-port/interface/name', 'string')
cps_utils.add_attr_type('base-port/interface/mac-address', 'hex')


def set_obj_val(obj, key, val):
    obj.add_attr(key, val)


def make_if_obj(d={}):
    return cps_object.CPSObject(module='base-port/interface', data=d)


def make_phy_obj(d={}):
    return cps_object.CPSObject(module='base-port/physical', data=d)


def make_hwport_obj(d={}):
    return cps_object.CPSObject(module='base-port/hardware-port', data=d)


def make_fp_obj(d={}):
    return cps_object.CPSObject(module='base-port/front-panel-port', data=d)


def nas_os_if_list(d={}):
    l = []
    filt = make_if_obj(d)

    if cps.get([filt.get()], l):
        return l
    return None


def nas_os_phy_list(d={}):
    l = []
    filt = make_phy_obj(d)

    if cps.get([filt.get()], l):
        return l
    return None

def nas_os_hwport_list(d={}):
    l = []
    filt = make_hwport_obj(d)

    if cps.get([filt.get()], l):
        return l
    return None

def nas_os_fp_list(d={}):
    l = []
    filt = make_fp_obj(d)

    if cps.get([filt.get()], l):
        return l

    return None


def name_to_ifindex(ifname):
    ifs = nas_os_if_list()
    for intf in ifs:
        obj = cps_object.CPSObject(obj=intf)
        name = obj.get_attr_data('name')
        if name == ifname:
            return obj.get_attr_data('ifindex')

    return None


def ifindex_to_name(ifindex):
    intf = nas_os_if_list({'ifindex': ifindex})
    if intf:
        obj = cps_object.CPSObject(obj=intf[0])
        return obj.get_attr_data('name')
    return None


def get_default_mtu():
    return 1532


def get_base_mac_address():
    obj = cps_object.CPSObject(module='base-pas/chassis', qual="observed")
    chassis = []
    cps.get([obj.get()], chassis)

    base_mac_address = chassis[0]['data'][
        'base-pas/chassis/base_mac_addresses']
    return base_mac_address


def get_mac_address(base_mac, mac_offset):
    # lane is 0 based, port MAC starts after base_address
    mac = base_mac[:]

    offset = mac_offset
    ix = 5
    while ix >= 0:
        val = mac[ix] + offset
        mac[ix] = val % 256
        if val <= 255:
            break
        offset = int(val / 256)
        ix -= 1
    return mac


class IfComponentCache(object):

    def _list(self, type):
        obj = cps_object.CPSObject(module=type)
        l = []
        cps.get([obj.get()], l)
        return l

    def print_keys(self):
        for k in self.m:
            print k

    def __init__(self):
        self.m = {}

    def exists(self, name):
        return name in self.m

    def get(self, name):
        if not self.exists(name):
            return None
        return self.m[name]

    def len(self):
        return len(self.m)


class FpPortCache(IfComponentCache):

    def make_media_key(self, slot, media):
        return 'media-%d-%d' % (slot, media)

    def __init__(self):
        IfComponentCache.__init__(self)
        l = self._list('base-port/front-panel-port')
        for e in l:
            obj = cps_object.CPSObject(obj=e)
            self.m[obj.get_attr_data('default-name')] = obj
            # in the future also key unit, slot as part of this since it is the
            # entire key
            self.m[obj.get_attr_data('front-panel-port')] = obj
            self.m[self.make_media_key(
                   obj.get_attr_data('slot-id'),
                   obj.get_attr_data('media-id'))] = obj

    def get_by_media_id(self, slot, media_id):
        return self.get(self.make_media_key(slot, media_id))


class PhyPortCache(IfComponentCache):

    def get_phy_port_cache_keys(self, unit, slot, npu, port):
        return "port-%d-%d-%d-%d" % (unit, slot, npu, port)

    def get_phy_port_cache_hw_keys(self, unit, slot, npu, port):
        return "hw-%d-%d-%d-%d" % (unit, slot, npu, port)

    def __init__(self):
        IfComponentCache.__init__(self)
        self.l = self._list('base-port/physical')
        self.m = {}

        for i in self.l:
            ph = cps_object.CPSObject(obj=i)
            self.m[
                self.get_phy_port_cache_hw_keys(
                    ph.get_attr_data('unit-id'),
                    ph.get_attr_data('slot-id'),
                    ph.get_attr_data('npu-id'),
                    ph.get_attr_data('hardware-port-id'))
            ] = ph
            self.m[self.get_phy_port_cache_keys(ph.get_attr_data('unit-id'),
                                                ph.get_attr_data(
                                                    'slot-id'), ph.get_attr_data('npu-id'),
                                                ph.get_attr_data('port-id'))] = ph

    def get_by_port(self, unit, slot, npu, port):
        return self.get(self.get_phy_port_cache_keys(unit, slot, npu, port))

    def get_by_hw_port(self, unit, slot, npu, port):
        return self.get(self.get_phy_port_cache_hw_keys(unit, slot, npu, port))

    def get_port_list(self):
        return self.l


class IfCache(IfComponentCache):

    def get_phy_port_cache_keys(self, unit, slot, npu, port):
        return "port-%d-%d-%d-%d" % (unit, slot, npu, port)

    def __init__(self):
        IfComponentCache.__init__(self)
        l = self._list('base-port/interface')
        for i in l:
            try:
                obj = cps_object.CPSObject(obj=i)
                self.m[obj.get_attr_data('name')] = obj
                #@!TODO.. add the real unit id
                self.m[self.get_phy_port_cache_keys(
                    0,
                    obj.get_attr_data('slot-id'),
                    obj.get_attr_data('npu-id'),
                    obj.get_attr_data('port-id')) ] = obj
            except:
                continue

    def get_by_port(self, unit, slot, npu, port):
        return self.get(self.get_phy_port_cache_keys(unit, slot, npu, port))


def get_interface_name(chassis, slot, port, lane):
    return 'e%d%02d-%03d-%d' % (chassis, slot, port, lane)

def make_interface_from_phy_port(fp_port_cache, base_mac, obj):
    if base_mac is None:
        base_mac = get_base_mac_address()

    slot = obj.get_attr_data('slot-id')
    npu = obj.get_attr_data('npu-id')
    hw_port_id = obj.get_attr_data('hardware-port-id')

    l = []
    elem = cps_object.CPSObject(module='base-port/hardware-port', data={
        'slot-id': slot,
        'npu-id': npu,
        'hw-port': hw_port_id
    })
    cps.get([elem.get()], l)
    if len(l) == 0:
        print "Invalid port specified... "
        print elem.get()
        raise Exception("Invalid port - no matching hardware-port")

    elem = cps_object.CPSObject(obj=l[0])

    # map from hardware port to front panel port to get the correct default name...
    # also use the physical port lane info for mac address manipulation
    fp_obj = fp_port_cache.get(elem.get_attr_data('front-panel-port'))
    if fp_obj is None:
        print "Could not find matching front panel port... %d " % elem.get_attr_data(
                'front-panel-port')
        print elem.get()
        raise Exception("Invalid hardware/front panel port combination..")

    #@!TODO.. use the real chassis_id as unit id
    chassis_id = default_chassis_id
    #@!TODO.. use the real slot id
    slot_id = default_slot_id
    port_id = elem.get_attr_data('front-panel-port')
    lane = elem.get_attr_data('subport-id')
    mode = elem.get_attr_data('fanout-mode')
    if mode != 4:  # 1x1
        lane += 1
    name = get_interface_name(chassis_id, slot_id, port_id, lane)
    _mac_offset = fp_obj.get_attr_data('mac-offset')

    # next generate the correct MAC address
    _mac = get_mac_address(base_mac, _mac_offset+lane)
    _macstr = bytearray_utils.ba_to_value('hex', _mac)

    # extract the port number from the phy port strcture (based on the hwid)
    port = obj.get_attr_data('port-id')

    # setting default MTU size during interface creation.
    _mtu = get_default_mtu()

    ifobj = cps_object.CPSObject(module='base-port/interface', data={
        'name': name, 'npu-id': npu, 'port-id': port, 'mtu': _mtu, 'mac-address': _macstr})

    return ifobj


def physical_ports_for_front_panel_port(fp_obj):
    # replace with object get attr data
    ports = fp_obj.get()['data']['base-port/front-panel-port/port']

    unit = fp_obj.get_attr_data('unit-id')
    slot = fp_obj.get_attr_data('slot-id')
    npu = fp_obj.get_attr_data('npu-id')

    l = []
    phy_port_list = []
    phy_port_cache = PhyPortCache()

    for i in ports:
        _port = cps_object.types.from_data(
            'base-port/front-panel-port/port',
            i)
        phy_port = phy_port_cache.get_by_hw_port(unit, slot, npu, _port)
        if phy_port is None:
            continue
        phy_port_list.append(phy_port)

    return phy_port_list

class npuPort:
    def __init__(self):
        self.npu = 0
        self.port = 0
def get_phy_port_from_if_index(if_index):
    l = nas_os_if_list(d={'ifindex':if_index})
    if l == None:
        return None

    phy_port = npuPort()
    obj = cps_object.CPSObject(obj=l[0])
    phy_port.npu = obj.get_attr_data('npu-id')
    phy_port.port = obj.get_attr_data('port-id')
    return phy_port

class hwPort:
    def __init__(self):
        self.npu = 0
        self.hw_port = 0
        self.unit = 0
        self.slot = 0

def get_hwport_from_phy_port(npu, port):
    port = nas_os_phy_list(d={'npu-id':npu,'port-id':port})
    if port == None:
        return None
    port_obj = cps_object.CPSObject(obj=port[0])

    hwport_details = hwPort()
    hwport_details.hw_port = port_obj.get_attr_data('hardware-port-id')
    hwport_details.npu = port_obj.get_attr_data('npu-id')
    hwport_details.unit = port_obj.get_attr_data('unit-id')
    hwport_details.slot = port_obj.get_attr_data('slot-id')
    return hwport_details

def get_fp_from_hw_port(npu, hw_port):
    hwport_list = nas_os_hwport_list(d={'npu-id':npu, 'hw-port':hw_port})
    if hwport_list == None:
        return None
    hwport_obj = cps_object.CPSObject(obj=hwport_list[0])
    fp_port = hwport_obj.get_attr_data('front-panel-port')
    return fp_port


def get_media_id_from_fp_port(fp_port):
    fp_port_list = nas_os_fp_list()
    media_id = None
    for fp in fp_port_list:
        obj = cps_object.CPSObject(obj=fp)
        if fp_port == obj.get_attr_data('front-panel-port'):
            media_id =  obj.get_attr_data('media-id')
            break
    return media_id

# functions for mapping speed, duplex and autneg to/from yang value

to_yang_speed_map = {
        0: 0,      # 0 Mbps
        10: 1,     # 10 Mbps
        100: 2,    # 100 Mbps
        1000: 3,   # 1GBPS
        10000: 4,  # 10 GBPS
        25000: 5,  # 25 GBPS
        40000: 6,  # 40GBps
        100000: 7, # 100Gbps
        }
from_yang_speed_map = {
        0: 0,      # 0 Mbps
        1: 10,     # 10Mbps
        2: 100,    # 100 Mbps
        3: 1000,   # 1Gbps
        4: 10000,  # 10Gbps
        5: 25000,  # 25 Gbps
        6: 40000,  # 40Gbps
        7: 100000, # 100Gbps
        }

def to_yang_speed(speed):
    return(to_yang_speed_map[speed])

def from_yang_speed(speed):
    return(from_yang_speed_map[speed])

def  to_yang_duplex(duplex):
    if duplex == "full":
        return(1)
    elif duplex == "half":
        return(2)
    else:   # AUTO
        return(3)

def  from_yang_duplex(duplex):
    if duplex == 1:
        return("full")
    elif duplex == 2:
        return("half")
    else:
        return("Error")

def to_yang_autoneg(autoneg):
    if autoneg == "on":
        return(True)
    else:
        return(False)

def from_yang_autoneg(autoneg):
    if autoneg == True:
        return("on")
    else:
        return("off")

# Set speed , duplex and autoneg
def nas_set_interface_attribute(if_index, speed, duplex, autoneg):
    if if_index == None:
        print 'not a valid interface index'
        return
    _data = {'ifindex':if_index}
    if speed != None:
        _data['speed']= speed
    if duplex != None:
        _data['duplex']= duplex
    if autoneg != None:
        _data['autoneg']= autoneg
    intf = cps_object.CPSObject(module='base-port/interface', data=_data)
    ch = {'operation':'set', 'change':intf.get()}
    cps.transaction([ch])

